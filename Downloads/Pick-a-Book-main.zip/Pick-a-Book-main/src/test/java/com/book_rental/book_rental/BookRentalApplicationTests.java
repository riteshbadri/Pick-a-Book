package com.book_rental.book_rental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookRentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
